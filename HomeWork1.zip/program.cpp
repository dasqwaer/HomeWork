#include <iostream>
int main (int argc, char**args)
{
std::cout << "Привет, мир!" << std::endl;
return 0;
}
